df = inputTable("Send a .csv-Table")

print(df)