# Example csv can be found in the zip archive which
# you can download via the download example data button

df = inputTable("Send a .csv-Table")

print(df)