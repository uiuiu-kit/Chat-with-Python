name = input("Who are you?")

print(f"Hello {name}")