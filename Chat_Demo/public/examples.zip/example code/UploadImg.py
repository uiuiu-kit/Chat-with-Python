img = inputImg('Send an Image!')

img.show()